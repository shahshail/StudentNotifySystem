/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/AddClass"})
public class AddClass extends HttpServlet {

    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
     
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
        
         try{
            String classid = request.getParameter("classid");
          String classname = request.getParameter("classname");
           String dept = request.getParameter("dept");
           String semester = request.getParameter("semester");
         String deptpad = String.format("%02d" ,Integer.parseInt(dept));
           Class.forName("com.mysql.jdbc.Driver");
//             out.println("Connecting to a selected database...");
                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    
                    PreparedStatement pt = cn.prepareStatement("insert into class_detail values(?,?,?,?)");
                    
                   pt.setString(1, classid);
                   pt.setString(2, classname);
                   pt.setString(3, deptpad);
                   pt.setString(4, semester);
                   
                    int count= pt.executeUpdate();
                  
                   if(count>0)
                {
                   response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Classes.jsp");
//               String m="sdfsdfd";
//               request.setAttribute("Message", m);
//                   RequestDispatcher dispatcher = request.getRequestDispatcher("/Addclass.jsp");
//              dispatcher.forward( request, response);
                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println("error");
    }

    }
}