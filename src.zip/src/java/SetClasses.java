/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DHRUMIT
 */
class SetClasses {
    
    public String Dept_Id;
    public String Class_Id;
    public String Class_Name;

    public void setDept_Id(String Dept_Id) {
        this.Dept_Id = Dept_Id;
    }

    public void setClass_Id(String Class_Id) {
        this.Class_Id = Class_Id;
    }

    public void setClass_Name(String Class_Name) {
        this.Class_Name = Class_Name;
    }

    public String getDept_Id() {
        return Dept_Id;
    }

    public String getClass_Id() {
        return Class_Id;
    }

    public String getClass_Name() {
        return Class_Name;
    }

   
    
     public SetClasses()
    {
    
    }
     public SetClasses(String d, String cid, String cname)
    {
        Dept_Id=d;
        Class_Id=cid;
        Class_Name=cname;
    }
    
}
