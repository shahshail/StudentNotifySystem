/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Combo_servlet"})
public class Combo_servlet extends HttpServlet {

   @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
        

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        PrintWriter out=response.getWriter();
         out.println("<script>"
       
        + "var combo = window.parent.document.getElementById('classes');"
        + " var option =window.parent.document.createElement('option'); "
        + " option.text = 'Test' ;"
        + "option.value ='Test'; "
        + "combo.add(option, null) </script> ");
//out.print("<script>window.parent.document.deptcombo.txtObjId.value ='"+ request.getParameter("selectValue").trim() +"'");
//out.print("</script>");
//       ArrayList<SetClasses> l1= new ArrayList<>();    
        
//        try{
//        Class.forName("com.mysql.jdbc.Driver");
//        Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update","root","root");
//
//        Statement st = cn.createStatement();
//            ResultSet rs = st.executeQuery("select  Class_Id,Class_Name  from class_detail,department_detail"
//                  +" where class_detail.Dept_Id=department_detail.Dept_Id and department_detail.Dept_Id='"+ request.getParameter("d") +"'");
////            //rs.next();
//////       while(rs.next()) 
//////       {
////        out.print("<script>window.parent.document.deptcombo.txtObjId.value ='"+rs.getString(1)+"'");
////        
//while(rs.next())
//{
//    
//    out.print("<script>var combo = window.parent.document.getElementById('classes')"
//            + "var option = window.parent.document.createElement('option')"
//            + "option.text='test'"
//            + "option.value='test'"
//            + "combo.add(option, null)</script>");
//// 
//       out.print("<script>var combo = window.parent.document.getElementById('classes'); "
//               + "var option =window.parent.document.createElement('option');"
//               +"option.text='abc'");
//       out.print("option.text");
//        out.print("combo.add("+rs.getString(1)+");");
//        out.print("option.text");
//
//out.print("</script>");

    


//          out.print("<script>"
//               + 
//              );
//           out.print( "option.text ='"+ request.getParameter("selectValue").trim() +"'");
//          int i;
//             for(i=0;i<l1.size();i++)
//             {
//               // out.print("var option =window.parent.document.deptcombo.createElement("+l1.get(i).getClass_Id()+ ");"
//                           
//                     
//                    
//             }    
                  
//               + "window.parent.document.deptcombo.txtObjId.value ='"+rs.getString(1)+"'");
//             out.print("<script>window.parent.document.deptcombo.txtObjId.value ='"+rs.getString(1)+"'");
//out.print("</script>");

//          
//              out.println("connecting..");
              
//                
              
//             SetClasses obj=new SetClasses();
//             
//             obj.setClass_Id(rs.getString(1));
////             obj.setClass_Name(rs.getString(2));
////             obj.setDept_Id(request.getParameter("selectValue"));
//             l1.add(obj);
             
             
             
              
//               int i;
//             for(i=0;i<l1.size();i++)
//             {
//               // out.print("var option =window.parent.document.deptcombo.createElement("+l1.get(i).getClass_Id()+ ");"
//                            out.print( "option.text ='" l1.get(i).getClass_Name()+"'; ");
//                      out.print("combo.add(option, null);");
//                    
//             }    
////               + "option.text ='"+l1.get(2).getClass_Name()+ "' ;"
//////               + "combo.add(option, null);");
////             //  + "var option1 =window.parent.document.createElement('option');"
////             //  + "option1.text = 'Test1' ; combo.add(option1, null); alert('Done ');");
//               out.print("</script>");  
////   
             
//       out.print("<script>window.parent.document.deptcombo.txtObjId.value = ' dbValue '; "
//               + "var combo = window.parent.document.getElementById('classes'); "
//               + "var option =window.parent.document.createElement('option');  "
//               + "option.text = 'Test' ;"
//               + "combo.add(option, null);"
//               + "var option1 =window.parent.document.createElement('option');"
//               + "option1.text = 'Test1' ; combo.add(option1, null); alert('Done ');");
//               out.print("</script>");  
//        out.print("<script>var combo = window.parent.document.getElementById('classes');"
//        + "var option =window.parent.document.createElement('option');  option.text = 'Test' ; combo.add(option, null);");
      
                  
               
//         }
//        
//          rs.close();
//            st.close();
//            cn.close();
////            
//////            response.sendRedirect("http://localhost:8080/My_College_Updates/admin/Adminhome.jsp");
////            
//        }
//        
//        catch(Exception e)
//        {
//            out.print("<script>window.parent.document.deptcombo.txtObjId.value ='"+ e.getMessage()+"'");
//out.print("</script>");//out.println("error");
//        }
        // ((HttpServletRequest)request).setAttribute("l1", l1);
////         request.setAttribute("name", name);
         //    RequestDispatcher rd = getServletContext().getRequestDispatcher("http://localhost:8080/My_College_Updates/Faculty/SelectAndUpload.jsp");
         //      rd.forward(request, response);
//    
    }
}

