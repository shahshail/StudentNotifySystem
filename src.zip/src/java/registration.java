/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/registration"})
public class registration extends HttpServlet {
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
        
        
//        processRequest(request, response);
    }
       @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter();
        PrintWriter out=response.getWriter();
        try{
            String Fid = request.getParameter("Fid");
          String Fname = request.getParameter("Fname");

          String Email_Id = request.getParameter("Email_Id");
          String Mobile_Number = request.getParameter("Mobile_Number");
          String Department = request.getParameter("deptt");
          String deptpad = String.format("%02d" ,Integer.parseInt(Department));
          String Icard_Number = request.getParameter("Icard_Number");
          String Password= request.getParameter("pass1"); 
          String Type= request.getParameter("type"); 
          String code= request.getParameter("code"); 
          
         
       Class.forName("com.mysql.jdbc.Driver");
//             out.println("Connecting to a selected database...");
                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
//                   out.println("Connected database successfully..."); 
                    PreparedStatement s = cn.prepareStatement("select count(*) from icardno where Staff_Id = ? and Fcode = ?");
                   s.setString(1, Fid);
                   s.setString(2, Icard_Number);
                   ResultSet rs= s.executeQuery();
                   rs.next();
                   int count= rs.getInt(1);
                   
                                       
                    if(!(count>0)){
                        out.println("Fid and Icard-Number doesnot match");
                    }
        else
                    {
                      
                   PreparedStatement pt= cn.prepareStatement("insert into faculty_detail values(?,?,?,?,?,?,?,?)"); 
                   pt.setString(1, Fid);
                   pt.setString(2, Fname);
                   pt.setString(3, Email_Id);
                   pt.setString(4, Mobile_Number);
                   pt.setString(5, deptpad);
                   pt.setString(6, Icard_Number);
                   pt.setString(7, Password);
                  pt.setString(8, "F");
                int i= pt.executeUpdate();
                
                if(i>0)
                {
                    
               response.sendRedirect("http://localhost:8080/My_College_Updates/Faculty/login.jsp");
                }
                   cn.close();
                        }
        }
        catch(Exception e)
        {
            out.println("Errors..."+e);
        }
         
        
     
       
           
    }

}
