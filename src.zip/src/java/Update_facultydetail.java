/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Update_facultydetail"})
public class Update_facultydetail extends HttpServlet {

  
 @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
        
//        processRequest(request, response);
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
        
        try{
             String Fid = request.getParameter("Fid");
            String Fname = request.getParameter("Fname");
          String emailid = request.getParameter("Email_Id");
         
          String mo_number = request.getParameter("Mobile_Number");
           String dept = request.getParameter("deptt");
            String pass = request.getParameter("pass1");
             String icard = request.getParameter("Icard_Number");
          String q="update faculty_detail set Faculty_Id=?, Name=?, Email_Id=? , Ph_No=?, Dept_Id=?, Icard_Number=?, fpassword=?  where Faculty_Id=?";

           Class.forName("com.mysql.jdbc.Driver");

                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    
                   PreparedStatement pstmt = cn.prepareStatement(q);
                    
                  pstmt.setString(1, Fid);
                   pstmt.setString(2, Fname);
                   pstmt.setString(3, emailid);
                   pstmt.setString(4, mo_number);
                   pstmt.setString(5, dept);
                  pstmt.setString(6, icard);
                  pstmt.setString(7, pass);
                  pstmt.setString(8, Fid);
                   
                   int count= pstmt.executeUpdate();
                  
                   if(count>0)
                {
                    
               response.sendRedirect("http://localhost:8080/My_College_Updates/admin/view_Faculty.jsp");
                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println(e);
    }
    
        }
    }
   
    

