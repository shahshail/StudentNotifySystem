/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Addbatch"})
public class Addbatch extends HttpServlet {

    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
     
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
       
         try{
             
         String batch = request.getParameter("batchname");
          String classid = request.getParameter("classid");
           
           String semester = request.getParameter("semester");
           String dept = request.getParameter("dept");
           String deptpad = String.format("%02d" ,Integer.parseInt(dept));
           
           Class.forName("com.mysql.jdbc.Driver");
//             out.println("Connecting to a selected database...");
                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    
                    PreparedStatement pt = cn.prepareStatement("insert into batch_detail(Batch_Name,Class_Id,Dept_Id,Semester) values(?,?,?,?)");
                   
                   pt.setString(1, batch);
                   pt.setString(2, classid);
                   pt.setString(3, deptpad); 
                   pt.setString(4, semester);
                    
                   int c= pt.executeUpdate();
                  
                   if(c>0)
                {
                     response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Batch.jsp");
////                out.println("done");
//                String m = "hello";
//             //   request.setAttribute("message", "hello");
//             //  request.getRequestDispatcher("Addbatch.jsp").forward(request, response);
//                    response.sendRedirect("http://localhost:8080/My_College_Updates/admin/Addbatch.jsp?message=" + m );
////                    String m="sdfsdfd";
////////                    request.getSession().setAttribute("message", "done");
//////                    request.setAttribute("Message", m);
////                   request.getRequestDispatcher("http://localhost:8080/My_College_Updates/admin/Addbatch.jsp").forward(request, response);
////               
////                    response.sendRedirect(request.getHeader("Referer"));
//                
                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println("error"+e);
    }

    }
}