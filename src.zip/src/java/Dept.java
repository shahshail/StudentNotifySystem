/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DHRUMIT
 */
public class Dept {
    
     public int deptid;
    public String deptname;
   

    public void setDeptid(int deptid) {
        this.deptid = deptid;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public int getDeptid() {
        return deptid;
    }

    public String getDeptname() {
        return deptname;
    }

    public Dept()
    {
    
    }
     public Dept(int dno, String dname)
    {
    deptid=dno;
    deptname=dname;
    }
}
