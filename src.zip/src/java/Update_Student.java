/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Update_Student"})
public class Update_Student extends HttpServlet {

 @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
        
//        processRequest(request, response);
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
        
        try{
            String Erno = request.getParameter("erno");
          String Name = request.getParameter("Fname");
          String phno = request.getParameter("mobile");
          String dept = request.getParameter("deptt");
          String deptpad = String.format("%02d" ,Integer.parseInt(dept));
          String sem = request.getParameter("sem");
          String classes = request.getParameter("classes");
          String batch = request.getParameter("Batch");
          String q="update student_detail set Enrollment_No=?, Name=?, Phone_No=? , Department=?, Semester=?, Class=?, Batch=?"
                  + " where Enrollment_No=?";

           Class.forName("com.mysql.jdbc.Driver");

                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    
                   PreparedStatement p1 = cn.prepareStatement(q);
                    
                   p1.setString(1, Erno);
                   p1.setString(2, Name);
                   p1.setString(3, phno);
                   p1.setString(4, deptpad);
                   p1.setString(5, sem);
                   p1.setString(6, classes);
                   p1.setString(7, batch);
                     p1.setString(8, Erno);
                   int count= p1.executeUpdate();
                  
                   if(count>0)
                {
                    
               response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Students.jsp");
                }
                else{
                out.println("ërror");
                }
                   p1.close();
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println(e);
    }
    
        }
    }
   
    

