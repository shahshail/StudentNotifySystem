/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Admin_Upload"})
@MultipartConfig(maxFileSize = 16177215)
public class Admin_Upload extends HttpServlet {
@Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }

    @Override
     protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
         PrintWriter out=response.getWriter();
         
         
      HttpSession session = request.getSession(true);
      
      
        try{
            String name = request.getParameter("topic");
            String Dept_Name= request.getParameter("department");
            String deptpad = String.format("%02d" ,Integer.parseInt(Dept_Name));
            String Semester= request.getParameter("sem");
            String classes= request.getParameter("classes");
            String batch= request.getParameter("batch");
          InputStream inputStream = null;
           out.println("Connecting to a selected database...");
           
          Part filePart = request.getPart("fileField");
           if (filePart != null) {
            // prints out some information for debugging
            out.println(filePart.getName());
            out.println(filePart.getSize());
            out.println(filePart.getContentType());
             out.println(filePart.getSubmittedFileName());
            // obtains input stream of the upload file
            inputStream = filePart.getInputStream();
        }
         
           Class.forName("com.mysql.jdbc.Driver");
           Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    String setlimit= "SET GLOBAL max_allowed_packet=104857600;";
                    Statement set = cn.createStatement();
                    set.execute(setlimit);
                   
                    Calendar calendar = Calendar.getInstance();
    java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());
                    
                    PreparedStatement pt = 
                            cn.prepareStatement("insert into circular_detail (Topic,Description,Date,UploadedBy,Dept_Id,Semester,Class_Id,Batch_Id) "
                                    + "values(?,?,?,?,?,?,?,?)");
                    
                   pt.setString(1, name);
                    if (inputStream != null) {
               
                pt.setBlob(2, inputStream);
            }
                   pt.setDate(3, ourJavaDateObject);
                   pt.setString(4, (String) session.getAttribute("name"));
                   pt.setString(5, deptpad);
                   pt.setString(6, Semester);
                   pt.setString(7, classes);
                   pt.setString(8, batch);
                    int count= pt.executeUpdate();
                   out.println("inserting record...");
                   if(count>0)
                {
                    response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Circulars.jsp");

                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println("error");
    }

    }
} 
         
         
         
         
         
         
         
         
         