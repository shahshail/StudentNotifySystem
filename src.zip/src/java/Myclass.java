/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DHRUMIT
 */
public class Myclass {
    
   public String class_Id;
   public String class_Name;

    public void setClass_Id(String Class_Id) {
        this.class_Id = Class_Id;
    }

    public void setClass_Name(String Class_Name) {
        this.class_Name = Class_Name;
    }

    public String getClass_Id() {
        return class_Id;
    }

    public String getClass_Name() {
        return class_Name;
    }
    
    public Myclass()
    {
    
    }
     public Myclass(String cid, String cname)
    {
            class_Id= cid;
            class_Name= cname;
    }
    
    
}
