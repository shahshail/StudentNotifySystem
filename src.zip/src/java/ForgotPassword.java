/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/ForgotPassword"})
public class ForgotPassword extends HttpServlet {
 private String host;
    private String port;
    private String user;
    private String pass;
    
 
    @Override
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = context.getInitParameter("host");
        port = context.getInitParameter("port");
        user = context.getInitParameter("user");
        pass = context.getInitParameter("pass");
    }
 
     @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        // reads form fields
        String Email_ID = request.getParameter("email");
      
        //String subject = request.getParameter("subject");
        //String content = request.getParameter("content");
        
        
 
        String resultMessage = "";
 
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");  
            String query="select fpassword from faculty_detail where Email_ID='"+Email_ID+"'";
            Statement st=null; 
            st = cn.createStatement();
            ResultSet rs= st.executeQuery(query);
            rs.next();
            String password = rs.getString(1);
            String to = Email_ID;
            String subject = "Password recovery";
            String content = "Your Email id is = " + Email_ID + "\nYour password is = "+password;
            
            EmailUtility.sendEmail(host, port, user, pass, to, subject,
                    content);
            resultMessage = "The e-mail was sent successfully";
        } catch (Exception ex) {
            resultMessage = "There were an error: " + ex.getMessage();
        } finally {
            
            
            request.setAttribute("Message", resultMessage);
            getServletContext().getRequestDispatcher("/Faculty/Result.jsp").forward(request, response);
        }
    }

}
  