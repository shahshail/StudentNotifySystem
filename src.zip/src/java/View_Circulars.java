/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.mysql.jdbc.PreparedStatement;
import static com.sun.faces.facelets.util.Path.context;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/View_Circulars"})
public class View_Circulars extends HttpServlet {

   
    
   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
      
        Blob image = null;
      Connection con = null;
      Statement stmt = null;
      ResultSet rs = null;
      ServletOutputStream out = response.getOutputStream();
       String name =request.getParameter("name");
      
    try{
        Class.forName("com.mysql.jdbc.Driver");
        
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
         
        String sql = "select Description from circular_detail where Topic='"+ name +"'";
        stmt = con.createStatement();
       
        rs = stmt.executeQuery(sql);
        
        if (rs.next()) {
      image = rs.getBlob(1);
      } else {
      response.setContentType("text/html");

      out.println(" not found ");

      return;
      }
        
        ServletContext context = getServletContext();
        String mimeType = context.getMimeType(name);
                
                 if (mimeType == "application/pdf") {        
                 response.setContentType(mimeType);
                }   
        
         if (mimeType == "image/png") {        
                 response.setContentType(mimeType);
                }   
        if (mimeType == "image/jpeg") {        
                 response.setContentType(mimeType);
                }   
       if (mimeType == "image/gif") {        
                 response.setContentType(mimeType);
                } 
       
             
//          response.setContentType();
//           response.setContentType();
//          response.setContentType("application/pdf");
//   
//          
   
          InputStream in = image.getBinaryStream();
          OutputStream outputStream = response.getOutputStream();
  int length = (int) image.length();
  int bufferSize = 1024;
  byte[] buffer = new byte[bufferSize];
  while ((length = in.read(buffer)) != -1) {
  outputStream.write(buffer, 0, length);
  }
  in.close();
  out.flush();
  rs.close();
  stmt.close();
  con.close();
    }
       
      catch (Exception e) {
  response.setContentType("text/html");
  out.println("Unable To Display image");
  
  return;
  } 
    }
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    
}
    }
    
