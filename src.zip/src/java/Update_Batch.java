/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/Update_Batch"})
public class Update_Batch extends HttpServlet {
  
 @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
        
//        processRequest(request, response);
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
        
        try{
             String b_id = request.getParameter("batchid");
            String b_name = request.getParameter("batchname");
          String classid = request.getParameter("classid");
         
          String sem = request.getParameter("semester");
           String deptid = request.getParameter("dept");
          String q="update batch_detail set Batch_Id=?, Batch_Name=?, Class_Id=? , Dept_Id=?, Semester=? where Batch_Id=?";

           Class.forName("com.mysql.jdbc.Driver");

                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");
                    
                   PreparedStatement pstmt = cn.prepareStatement(q);
                    
                  pstmt.setString(1, b_id);
                   pstmt.setString(2, b_name);
                   pstmt.setString(3, classid);
                   pstmt.setString(4, deptid);
                   pstmt.setString(5, sem);
                  pstmt.setString(6, b_id);
                   
                   int count= pstmt.executeUpdate();
                  
                   if(count>0)
                {
                    
               response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Batch.jsp");
                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println(e);
    }
    
        }
    }
   
    

