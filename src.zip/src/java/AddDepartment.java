/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DHRUMIT
 */
@WebServlet(urlPatterns = {"/AddDepartment"})
public class AddDepartment extends HttpServlet {
    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
     
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.getWriter();
        PrintWriter out=response.getWriter();
        
         try{
            String Dept_Id = request.getParameter("deptid");
          String Dept_Name = request.getParameter("deptname");
          
           Class.forName("com.mysql.jdbc.Driver");
//             out.println("Connecting to a selected database...");
                   Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root");

                    
                    PreparedStatement p1 = cn.prepareStatement("insert into department_detail values(?,?)");
                    
                   p1.setString(1, Dept_Id);
                   p1.setString(2, Dept_Name);
                   
                    int count= p1.executeUpdate();
                  
                   if(count>0)
                {
                    
                response.sendRedirect("http://localhost:8080/My_College_Updates/admin/View_Department.jsp");
                }
                else{
                out.println("ërror");
                }
                   cn.close();
                        }
         catch(Exception e)
    {
    out.println(e);
    }

    }
}
   