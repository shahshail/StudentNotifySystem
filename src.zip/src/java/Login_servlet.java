/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.registry.infomodel.User;

/**
 *
 * @author DHRUMIT
 */

@WebServlet(urlPatterns = {"/Login_servlet"})
public class Login_servlet extends HttpServlet {
    
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    
    static final String USER = "root";
    static final String PASS = "root";

 
    @Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doPost(request,response);
     }
        
//        processRequest(request, response);
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
      response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        try {
            
                String username = request.getParameter("user");
                String pwd = request.getParameter("pwd");
             
                
              HttpSession session = request.getSession(true);  
        if(session!=null)  {
        session.setAttribute("name", username);
        }
                Class.forName(JDBC_DRIVER);
            try (Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/coll_update?user=root")) {
                PreparedStatement ps = cn.prepareStatement("select count(*) from faculty_detail where Faculty_Id = ? and fpassword = ?");
               
                ps.setString(1, username);
                ps.setString(2, pwd);
                ResultSet rs= ps.executeQuery();
                rs.next();
                int count= rs.getInt(1);
                
              
                if(count>0){
                     
                    String admin="select userType from faculty_detail where Faculty_Id=?";
                            PreparedStatement ps2 = cn.prepareStatement(admin);
                           
                            ps2.setString(1, username);
                     ResultSet rs2= ps2.executeQuery();
                    rs2.next();
               
                    String t= rs2.getString(1);
                    
                     if(t.equals("A"))
                     {
                         response.sendRedirect("http://localhost:8080/My_College_Updates/admin/Adminhome.jsp");
                     
                     }
                     else
                     {
                        
                         response.sendRedirect("http://localhost:8080/My_College_Updates/Faculty/circulars.jsp");
                         
                     }
                   
                    
              
                    

                }
                else
                {
                    out.println("username or password is incorrect");
                }
                ps.close();
            }
        } catch(Exception e)
                {
                      out.println(e);  
                }
                
    }    

}  

    
    

